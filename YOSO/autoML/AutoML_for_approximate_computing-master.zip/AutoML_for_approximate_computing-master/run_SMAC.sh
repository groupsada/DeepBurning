#!/bin/bash
smac --scenario-file train-scenario.txt 